"use strict";
exports.id = 468;
exports.ids = [468];
exports.modules = {

/***/ 7650:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "w": () => (/* binding */ sendRequest)
/* harmony export */ });
/* eslint-disable @typescript-eslint/no-unsafe-return */ /* eslint-disable @typescript-eslint/restrict-template-expressions */ const base_url = "https://skylor-p.com/sleeps-api";
const sendRequest = async (method, apiUrl, payload, token)=>{
    const headers = new Headers({
        "Content-Type": "application/json"
    });
    if (token) {
        headers.append("Authorization", `Bearer ${token}`);
    }
    const options = {
        method: method,
        credentials: "include",
        headers,
        body: payload ? JSON.stringify(payload) : undefined
    };
    let url = `${base_url}${apiUrl}`;
    url = encodeURI(url);
    const res = await fetch(url, options);
    if (res.ok) {
        try {
            return await res.json();
        } catch (e) {
            console.log(`error with json ${e}`);
        }
    }
};


/***/ }),

/***/ 1717:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_2__);



const withAuth = (Component)=>{
    const AuthenticatedComponent = (props)=>{
        const { data: sessionData , status  } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_2__.useSession)();
        if (status === "loading") {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: "Loading..."
            });
        }
        if (!sessionData?.user) {
            void (0,next_auth_react__WEBPACK_IMPORTED_MODULE_2__.signIn)("google");
        }
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
            ...props
        });
    };
    return AuthenticatedComponent;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (withAuth);


/***/ })

};
;