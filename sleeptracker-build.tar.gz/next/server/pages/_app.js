(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 5567:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next-auth/react"
var react_ = __webpack_require__(1649);
// EXTERNAL MODULE: ./src/styles/globals.css
var globals = __webpack_require__(108);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./src/components/MobileMenu.tsx
/* eslint-disable @typescript-eslint/restrict-template-expressions */ /* eslint-disable @typescript-eslint/no-unsafe-member-access */ /* eslint-disable @typescript-eslint/no-misused-promises */ 

const MobileMenu = ({ isOpen , setIsOpen , sessionData , handleSignOut  })=>{
    const closeMenu = (e)=>{
        e.preventDefault();
        setIsOpen(false);
    };
    return isOpen ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "absolute top-0 left-0 z-50 h-full w-full",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "h-full w-full bg-black opacity-50",
                onClick: closeMenu
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "absolute top-0 left-0 z-10 h-full w-64 overflow-y-auto bg-white p-6",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "mb-4",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/sleep",
                            className: "text-lg font-semibold",
                            onClick: closeMenu,
                            children: "Sleep Calculator"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "mb-4",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            className: "text-lg font-semibold",
                            onClick: closeMenu,
                            href: `/sleeps/${sessionData.user.id}`,
                            children: "Sleep Log"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "mb-4",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            className: "text-lg font-semibold",
                            onClick: handleSignOut,
                            children: "Sign out"
                        })
                    })
                ]
            })
        ]
    }) : null;
};
/* harmony default export */ const components_MobileMenu = (MobileMenu);

;// CONCATENATED MODULE: ./src/components/Navbar.tsx






const Navbar = ()=>{
    const router = (0,router_.useRouter)();
    const { data: sessionData  } = (0,react_.useSession)();
    const [isOpen, setIsOpen] = (0,external_react_.useState)(false);
    const handlePathChange = async (path)=>{
        await router.push(path);
    };
    const handleSignOut = async ()=>{
        await (0,react_.signOut)({
            callbackUrl: "/sleep-tracker"
        });
    };
    const handleSignIn = async ()=>{
        await (0,react_.signIn)("google");
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex items-center justify-between px-4",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "logo flex items-center text-3xl font-bold text-blue-500",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "relative mr-2 h-8 w-8 overflow-hidden rounded-full bg-blue-500",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "absolute top-0 left-1 h-16 w-16 rounded-full bg-white"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            onClick: ()=>void handlePathChange("/"),
                            children: "Sleep Tracker"
                        })
                    })
                ]
            }),
            sessionData?.user ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "hidden items-center space-x-4 md:flex",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/sleep",
                        className: "text-lg font-semibold",
                        children: "Sleep Calculator"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: "|"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        className: "text-lg font-semibold",
                        href: `/sleeps/${sessionData.user.id}`,
                        children: "Sleep Log"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: "|"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                        className: "mr-5",
                        children: [
                            "Welcome, ",
                            sessionData?.user?.name
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                        tabIndex: 0,
                        className: "btn-ghost btn-circle avatar btn",
                        onClick: ()=>void handleSignOut(),
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "h-10 w-10 overflow-hidden rounded-full",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: sessionData?.user?.image ?? "",
                                alt: sessionData?.user?.name ?? "User",
                                className: "object-cover",
                                width: 50,
                                height: 40
                            })
                        })
                    })
                ]
            }) : /*#__PURE__*/ jsx_runtime_.jsx("button", {
                className: "btn-ghost rounded-btn btn hidden md:block",
                onClick: ()=>void handleSignIn(),
                children: "Sign in"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "md:hidden",
                children: sessionData?.user ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                    onClick: ()=>setIsOpen(!isOpen),
                    className: "focus:outline-none",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "mb-1 block h-0.5 w-6 bg-blue-500"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "mb-1 block h-0.5 w-6 bg-blue-500"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "block h-0.5 w-6 bg-blue-500"
                        })
                    ]
                }) : /*#__PURE__*/ jsx_runtime_.jsx("button", {
                    className: "btn-ghost rounded-btn btn",
                    onClick: ()=>void handleSignIn(),
                    children: "Sign in"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components_MobileMenu, {
                isOpen: isOpen,
                setIsOpen: setIsOpen,
                sessionData: sessionData,
                handleSignOut: handleSignOut
            })
        ]
    });
};

;// CONCATENATED MODULE: ./src/pages/_app.tsx




const MyApp = ({ Component , pageProps: { session , ...pageProps }  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.SessionProvider, {
        basePath: "/sleep-tracker/api/auth",
        session: session,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Navbar, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                ...pageProps
            })
        ]
    });
};
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 108:
/***/ (() => {



/***/ }),

/***/ 1649:
/***/ ((module) => {

"use strict";
module.exports = require("next-auth/react");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [664], () => (__webpack_exec__(5567)));
module.exports = __webpack_exports__;

})();