(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 3988:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next-auth/react"
var react_ = __webpack_require__(1649);
// EXTERNAL MODULE: ./src/styles/globals.css
var globals = __webpack_require__(108);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./src/components/Navbar.tsx





const Navbar = ()=>{
    const router = (0,router_.useRouter)();
    const { data: sessionData  } = (0,react_.useSession)();
    const handlePathChange = async (path)=>{
        await router.push(path);
    };
    const handleSignOut = async ()=>{
        await (0,react_.signOut)({
            callbackUrl: "/"
        });
    };
    const handleSignIn = async ()=>{
        await (0,react_.signIn)("google");
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex justify-between",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "logo flex items-center text-3xl font-bold text-blue-500",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "relative mr-2 h-8 w-8 overflow-hidden rounded-full bg-blue-500",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "absolute top-0 left-1 h-16 w-16 rounded-full bg-white"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            onClick: ()=>void handlePathChange("/"),
                            children: "Sleep Tracker"
                        })
                    })
                ]
            }),
            sessionData?.user ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex items-center space-x-4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/sleep",
                        className: "text-lg font-semibold",
                        children: "Sleep Calculator"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: "|"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        className: "text-lg font-semibold",
                        href: `/sleeps/${sessionData.user.id}`
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: "|"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                        className: "mr-5",
                        children: [
                            "Welcome, ",
                            sessionData?.user?.name
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                        tabIndex: 0,
                        className: "btn-ghost btn-circle avatar btn",
                        onClick: ()=>void handleSignOut(),
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "h-10 w-10 overflow-hidden rounded-full",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: sessionData?.user?.image ?? "",
                                alt: sessionData?.user?.name ?? "User",
                                className: "object-cover",
                                width: 50,
                                height: 40
                            })
                        })
                    })
                ]
            }) : /*#__PURE__*/ jsx_runtime_.jsx("button", {
                className: "btn-ghost rounded-btn btn",
                onClick: ()=>void handleSignIn(),
                children: "Sign in"
            })
        ]
    });
};

;// CONCATENATED MODULE: ./src/pages/_app.tsx




const MyApp = ({ Component , pageProps: { session , ...pageProps }  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.SessionProvider, {
        basePath: "/sleep-tracker/api/auth",
        session: session,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Navbar, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                ...pageProps
            })
        ]
    });
};
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 108:
/***/ (() => {



/***/ }),

/***/ 1649:
/***/ ((module) => {

"use strict";
module.exports = require("next-auth/react");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [636,61], () => (__webpack_exec__(3988)));
module.exports = __webpack_exports__;

})();